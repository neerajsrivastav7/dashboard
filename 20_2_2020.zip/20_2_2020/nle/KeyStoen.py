from keystoneauth1.identity import v3
from keystoneauth1 import session
from keystoneclient.v3 import client
import sys

auth = v3.Password(auth_url='http://192.168.30.5:5000/v3',
                   username='admin',
                   password='KDYc430Vp4Nsi1jiMbMypeCDviJTM016UynN6egp',
                   project_id='13de5928f71148a6a1f398d81e92f38d',
                   user_domain_id='default')
sess = session.Session(auth=auth)
ks = client.Client(session=sess)
users = ks.users.list()
#print users
given_users=sys.argv[1]
i=0
if given_users=="admin":
	given_roles="admin"
else:
	given_roles="_member_"
while i < len(users):
        if given_users == str(users[i].name):
                break
        i=i+1
show_user_id = str(users[i].id)
print show_user_id
#print show_project_id
#password_changed = ks.users.update(str(users[i].id), name=None, domain=None, project=None, password=user_newpassword, email=None, description=None, enabled=None, default_project=None)

#print "++++ password changed+++++"
#print  password_changed
#print "user "+ given_user +" password has been changed successfully."
roles = ks.roles.list()
#print users
#print "==user is ===="+ sys.argv[1] + "====password==== "+ sys.argv[2]
i=0
while i < len(roles):
        if given_roles == str(roles[i].name):
                break
        i=i+1
show_roles_id = str(roles[i].id)
print show_roles_id
k1=ks.role_assignments.list(user=show_user_id, group=None, project=None, domain=None, system=False, role=show_roles_id, effective=True, os_inherit_extension_inherited_to=None, include_subtree=False, include_names=True)
length=len(k1)
str=""
for i in range(0,length):
	k2=k1[i]
        k3=k2.scope
        if u'project' in k3.keys():
	        k4=k3[u'project']
                str=str+k4[u'name']
                str=str+"."
                
print str;
        
