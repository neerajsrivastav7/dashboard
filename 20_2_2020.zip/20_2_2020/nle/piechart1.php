<?php
session_start();
        if (!isset($_SESSION['username'])) {
                $_SESSION['msg'] = "You must log in first";
                header("location: login.php");
        }
?>
<?php
$_SESSION['project']=$_GET['id'];
$var1= $_SESSION['project'];
$given_project_id=  exec("python keystone_project_id.py $var1");;
$w=exec("python nova_limits.py $given_project_id");
$w1 = trim($w,"}");
$myArray = explode(',', $w1);
$newarray=  $myArray[1];
$array1 = explode(':', $newarray);
$a1 = array();
$lenth = sizeof($myArray);
for( $x = 0; $x < $lenth; $x++) {
            $v1 = $myArray[$x];
            $array1 = explode(':', $v1);
            $array2 = explode("'", $array1[0]);
            $a1[$array2[1]] = $array1[1];
         }
$c11=$a1['maxTotalInstances']-$a1['totalInstancesUsed'];
$c12=$a1['totalInstancesUsed'];
$c11=(int)$c11;
$c12=(int)$c12;
 $rating_data = array(
 array('Sandbox', 'Intences'),
 array('Used',$c12),
 array('Unused',$c11)
);
 $encoded_data = json_encode($rating_data);
 
$ramd1=$a1['maxTotalRAMSize']-$a1['totalRAMUsed'];
$ramd2=$a1['totalRAMUsed'];
$ramd1=(int)$ramd1;
$ramd2=(int)$ramd2;
$ram_array = array(
array('Sandbox', 'Ram'),
array('Used',$ramd2),
array('Unused',$ramd1)
);
 $Ram_encoded_data = json_encode($ram_array);

$cored1=$a1['maxTotalCores']-$a1['totalCoresUsed'];
$cored2=$a1['totalCoresUsed'];
$cored1=(int)$cored1;
$cored2=(int)$cored2;
$core_array = array(
array('Sandbox', 'Core'),
array('Used',$cored2),
array('Unused',$cored1)
);
 $core_encoded_data = json_encode($core_array);

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>NLE Sandbox</title>
  <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
 <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
  <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
  <script type="text/javascript" src="https://www.google.com/jsapi"></script>
  <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.8.2/jquery.min.js"></script>
  <link href="custom.css" rel="stylesheet"/>
  <link href="ddsumenu.css" rel="stylesheet"/>
  <style>
    .hower:hover {
  background-color: #555;
  color: white;
}
   .w3-btn,.w3-button{
text-align:left !important;
}

}
  </style>
        <script>
          google.charts.load('current', {'packages':['corechart']});
           google.charts.setOnLoadCallback(drawChart);
           google.charts.setOnLoadCallback(drawChart2);
           google.charts.setOnLoadCallback(drawChart3);
// Draw the chart and set the chart values
function drawChart() {
         var data = google.visualization.arrayToDataTable(
         <?php  echo $encoded_data; ?>
       );
  // Optional; add a title and set the width and height of the chart
       var options = {title:'Instances',legend:{position:'right'},colors:['#428bca','#ddd'] };
  // Display the chart inside the <div> element with id="piechart"
          var chart = new google.visualization.PieChart(document.getElementById('chart1'));
           chart.draw(data, options);
  
}
function drawChart2() {
         var data = google.visualization.arrayToDataTable(
         <?php  echo $Ram_encoded_data; ?>
       );
  // Optional; add a title and set the width and height of the chart
       var options = {title:'RAM',legend:{position:'right'},colors:['#428bca','#ddd'] };
  // Display the chart inside the <div> element with id="piechart"
          var chart = new google.visualization.PieChart(document.getElementById('chart2'));
           chart.draw(data, options);

}
function drawChart3() {
         var data = google.visualization.arrayToDataTable(
         <?php  echo $core_encoded_data; ?>
       );
  // Optional; add a title and set the width and height of the chart
       var options = {title:'VCPUs',legend:{position:'right'},colors:['#428bca','#ddd'] };
  // Display the chart inside the <div> element with id="piechart"
          var chart = new google.visualization.PieChart(document.getElementById('chart3'));
           chart.draw(data, options);

}

           $(document).ready(function(){
               $("#appOnBoard").click(function()
                   {
                        $("#appOnBoard").css("text-decoration", "underline");
                        $("#dataDiv").load("aobg.php #aobgd");
                 });
              });

           $(document).ready(function(){
             $("#oog").click(function()
                {
                    $("#oog").css("text-decoration", "underline");
                    $("#dataDiv").load("oog.php #oogd");
                });
            });
          $(document).ready(function(){
             $("#tog").click(function()
               {
                  $("#tog").css("text-decoration", "underline");
                  $("#dataDiv").load("tog.php #togd");
               });
           });
       $(document).ready(function(){
           $("#reg").click(function()
               {
                  $("#reg").css("text-decoration", "underline");
                  $("#dataDiv").load("reg.php #rid");
               });
        });
          $(document).ready(function(){
           $("#gos").click(function()
               {
                  $("#gos").css("text-decoration", "underline");
                  $("#dataDiv").load("Grosary.php #grosary_table");
               });
        });
        </script>
  </head>

<body>
  <?php if(isset($_SESSION['username'])){ ?>
  <div class="container id10">
      <?php include('template.php'); ?>
      <div class="row row3" style="padding-top:25px;">
     <div  class="col-md-12">
               <div id="dataDiv" class="customDiv2">
                   <div class="row">
                       <div class="col-md-4">
                           <div id="chart1"></div>
                        </div>
                        <div class="col-md-4">
                           <div id="chart2"></div>
                        </div>
                        <div class="col-md-4">
                           <div id="chart3"></div>
                        </div>
                   </div>
            </div>
           <!-- <div class="col-md-3">
               <div class="customDiv3">LINKbar3</div>
            </div>-->
      </div>
</div>
</div>
<?php }
else header('location: login.php'); ?>
<body>
</html>

