<?php
session_start();
        if (!isset($_SESSION['username'])) {
                $_SESSION['msg'] = "You must log in first";
                header("location: login.php");
        }
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>NLE Sandbox</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
 <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
  <link href="custom.css" rel="stylesheet"/>
  <link href="ddsumenu.css" rel="stylesheet"/>
  <style>
    .hower:hover {
  background-color: #555;
  color: white;
}
  .w3-btn,.w3-button{
text-align:left !important;
}

}
  </style>
        <script>
           $(document).ready(function(){
               $("#appOnBoard").click(function()
                   {
                        $("#appOnBoard").css("text-decoration", "underline");
                        $("#dataDiv").load("aobg.php #aobgd");
                 });
              });

           $(document).ready(function(){
             $("#oog").click(function()
                {
                    $("#oog").css("text-decoration", "underline");
                    $("#dataDiv").load("oog.php #oogd");
                });
            });
          $(document).ready(function(){
             $("#tog").click(function()
               {
                  $("#tog").css("text-decoration", "underline");
                  $("#dataDiv").load("tog.php #togd");
               });
           });
       $(document).ready(function(){
           $("#reg").click(function()
               {
                  $("#reg").css("text-decoration", "underline");
                  $("#dataDiv").load("reg.php #rid");
               });
        });
        $(document).ready(function(){
           $("#gos").click(function()
               {
                  $("#gos").css("text-decoration", "underline");
                  $("#dataDiv").load("Grosary.php #grosary_table");
               });
        });
     </script>

  </head>

<body>
  <?php if(isset($_SESSION['username'])){ ?>
  <div class="container id10">
       <div class="row row1">
             <div class="col-md-4 row_col1">
                 <div class="col1data" style="float:left;">
                          <figure>
                           <?php
                                $var=$_SESSION['domain'];
                                $dom=$var;
                            ?>
                            <img id="imid" style="align:center; float:left; height:40px;" src="images/<?php echo $dom ?>.png" alt="Cinque Terre">
                           <!-- <h3><figcaption>NEC</figcaption></h3>-->
                            </figure>
                   </div>
               </div>
             <div class="col-md-4 row_col2">
                 <div class="col2data"><h3 id="h11">Welcome To NLE Sandbox</h3></div>
             </div>
	              <div class="col-md-4 row_col3">
                         <div class="col3data" style="float:right;"> 
                          <figure>
                             <img style="float:right;" src="male.png" class="img-circle" alt="Cinque Terre" width="60" height="60">
                             <h3><figcaption><?php echo $_SESSION['username'] ?></figcaption></h3>
                          </figure>
                       </div>
                     </div>
		</div>
              <div class="row" style="padding-top:20px;">
             <div class="col-md-12">
              <nav class="navbar navbar-expand-md  navbar-dark bg-primary">

                  <ul class="navbar-nav">
                      <li class="nav-item">
                      <a class="nav-link hower" href="newnav.php" style="color:white;">Home</a>
                     </li>
                     <li class="nav-item">
                     <a class="nav-link hower" href="http://192.168.30.5/auth/login/?next=/" style="color:white;">Sandbox Portal</a>
                     </li>
                     <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle hower" href="#" id="navbardrop" data-toggle="dropdown" style="color:white;">
                        User Management
                     </a>
                      <ul class="dropdown-menu">
                     <!-- <li class="dropdown-item w3-bar-item w3-button"><a href="piechart1.php">Resource Overview</li>-->
                      <li class="dropdown-submenu">
                          <a  class="dropdown-item" tabindex="-1" href="#">Resource overview</a>
                          <ul class="dropdown-menu">
                                <?php
                                  $var=$_SESSION['username'];
                                  $username1 =$var;
                                  $return_string=exec("python KeyStoen.py  $username1");
                                  $project_arr = explode('.', $return_string);
                                  $lenth = sizeof($project_arr);
                                  for ($x = 0; $x<$lenth; $x++) {           
                                ?>
                                <li class="dropdown-item w3-bar-item w3-button"><a href="piechart1.php?id=<?php echo $project_arr[$x]; ?>" id="<?php echo $project_arr[$x]; ?>"><?php echo $project_arr[$x]; ?></a></li>
                                <?php } ?>
                            </ul>
                      </li>
                      <?php if($_SESSION['username']=='admin'){ ?><li class="dropdown-item w3-bar-item w3-button"><a href="Del2.php">View User</li><?php } ?>
                      
                      <li class="dropdown-item w3-bar-item w3-button"><a href="changepassword.php">Reset Password</li>
                      </ul>
                   </li>

    <!-- Dropdown -->
                  <li class="nav-item dropdown">
                      <a class="nav-link dropdown-toggle hower" href="#" id="navbardrop" data-toggle="dropdown" style="color:white;">
                        Documents
                     </a>
                    <ul class="dropdown-menu">
                      <li class="dropdown-item w3-bar-item w3-button" ><span id="appOnBoard" style="color:black; cursor:pointer; text-align:left;">Application Onboarding Guide</li>
                      <?php if($_SESSION['username']=='admin'){ ?><li class="dropdown-item w3-bar-item w3-button" ><span id="oog" style="color:black; cursor:pointer;">Openstack Onboarding Guide</li><?php } ?> 
                      <?php if($_SESSION['username']=='admin'){ ?><li class="dropdown-item w3-bar-item w3-button" ><span id="tog" style="color:black; cursor:pointer;">Tenant Onboarding Guide</li><?php } ?> 
                     <li class="dropdown-item w3-bar-item w3-button" ><span id="gos" style="color:black; cursor:pointer;">Glossary</li>
                   </ul>
               </li>
            </ul>
                    <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
                    <ul class="navbar-nav" style="float:right;">
                    <li class="fa fa-sign-out" style="font-size:18px"><a href="logout.php" style="color:white;">Logout</a></li>
                       </ul>
                    </div>
        </nav>
   </div>
 </div>
      <div class="row row3" style="padding-top:25px;">
     <div  class="col-md-12">
               <div id="dataDiv" class="customDiv2">
                <h3 style="padding-left:0px;color:green; text-align:center;">Introduction to Sandbox</h3></br>
                <p align="justify" style="font-size:14px;">
The notion of connecting every electronic, sensor or actuator device to the internet and making them communicate and exchange data has set the World on the beginning of another revolution. Convergence of various technologies together like Machine Learning, Sensors, Embedded systems, real-time analytics have given wings to the idea of Internet Of Things (or IOT). Only through IOT, one can think of smart cities where smart parking, smart automobiles, smart temperature and pollution check systems, smart lighting systems, etc. exist.
</p>
               <p align="justify" style="font-size:14px;">
                 To ease and accelerate the routine processes, smart devices can step-in. Smart devices can inform a driver about a broken or under-construction road beforehand, smart devices can tell where a car parking slot is available in the parking area, smart devices can serve as query system of an environment and much more.
              </p>
               <P align="justify" style="font-size:14px;">
                 For such an infrastructure or environment, there is a list of requirements like network connectivity, power enabled data sensors and actuators, computing devices with embedded or remote computing systems, data managers etc
               </P>
               <P align="justify" style="font-size:14px;">
                 This is where IOT Sandbox Solution steps in. IOT Sandbox solution is a cloud service dedicated for IOT data management that provides service at both PAAS and IAAS level. The platform applications provided by Sandbox can actually interact with the smart devices and manage the entire lifecycle of data using the cloud infrastructure from sensors to the actuators.
              </P>
               </div>
            </div>
           <!-- <div class="col-md-3">
               <div class="customDiv3">LINKbar3</div>
            </div>-->
      </div>
</div>
</div>
<?php }
else header('location: login.php'); ?>
<body>
</html>




