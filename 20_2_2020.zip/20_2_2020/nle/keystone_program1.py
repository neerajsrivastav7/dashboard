from keystoneauth1.identity import v3
from keystoneauth1 import session
from keystoneclient.v3 import client
import sys
import string
import random
def id_generator(size=6, chars=string.ascii_uppercase + string.digits):
	return ''.join(random.choice(chars) for _ in range(size))
auth = v3.Password(auth_url='http://192.168.30.5:5000/v3',
                   username='admin',
                   password='KDYc430Vp4Nsi1jiMbMypeCDviJTM016UynN6egp',
                   project_id='13de5928f71148a6a1f398d81e92f38d',
                   user_domain_id='default')
sess = session.Session(auth=auth)
ks = client.Client(session=sess)
users = ks.users.list()
#print users
#print "==user is ===="+ sys.argv[1] + "====password==== "+ sys.argv[2]
given_user = sys.argv[1]
user_newpassword=id_generator()
#print user_newpassword
i=0
while i < len(users):
	if given_user == str(users[i].name):
	#	print str(users[i].id)
                break
	i=i+1
try:
	password_changed = ks.users.update(str(users[i].id), name=None, domain=None, project=None, password=user_newpassword, email=None, description=None, enabled=None, default_project=None)
	print user_newpassword
except:
	print "false"
#print "++++ password changed+++++"
#print  password_changed
#print "user "+ given_user +" password has been changed successfully."

