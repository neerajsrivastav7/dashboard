
<!DOCTYPE html>
<html lang="en">
<head>
<title>Registration</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

</head>
<script>
</script>
<body>
	<div id="rid" class="container" style="padding-right:400px;">    
        <script>
             function validateForm() {
              console.log("validate form");           
             var p1 = document.forms["myForm"]["password_1"].value;
             var p2 = document.forms["myForm"]["password_2"].value;
             if (p1!=p2) {
              document.getElementById("demo1").innerHTML = "Hello World";
              return false;
  }
}
        </script>
        <?php include('server.php'); ?>
        <div id="loginbox" style="margin-top:50px;">                    
            <div class="panel panel-info" >
                    <div class="panel-heading">
                        <div class="panel-title">Register Here</div>
                    </div>     

                    <div style="padding-top:30px" class="panel-body" >

                        <div style="display:none" id="login-alert" class="alert alert-danger col-sm-12"></div>
                        <form method="post" action="reg.php" name="myForm" onsubmit="return validateForm()">
                            <div style="margin-bottom: 15px" class="input-group">
                                        <span class="input-group-addon"><i class="glyphicon glyphicon-asterisk"></i></span>
                                        <input id="login-username" type="text" class="form-control" name="domain" value="" placeholder="Domain" required/>                                        
                                    </div>
                            <div style="margin-bottom: 15px" class="input-group">
                                        <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                                        <input type="text" class="form-control" name="username" placeholder="User Name" >
                                    </div>
									 <div style="margin-bottom: 15px" class="input-group">
                                        <span class="input-group-addon"><i class="glyphicon glyphicon-envelope"></i></span>
                                        <input  type="email" class="form-control" name="email" placeholder="Email" /required/>
                                    </div>
									 <div style="margin-bottom: 15px" class="input-group">
                                        <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                                        <input type="password" class="form-control" name="password_1" placeholder="Password" required/>
                                    </div>
									 <div style="margin-bottom: 15px" class="input-group">
                                        <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                                        <input  type="password" class="form-control" name="password_2" placeholder="Confirm Password" required/>
                                  
                                    </div>
                                    <p id="demo1"></p>
									 <div style="margin-bottom: 15px" class="input-group">
                                        <span class="input-group-addon"><i class="glyphicon glyphicon-asterisk"></i></span>
                                        <input  type="text" class="form-control" name="project" placeholder="Project Name">
                                    </div>
                                <div style="margin-top:5px; float:right;" class="form-group">
                                    <div class="col-sm-12 controls">
                                      <button type="submit" id="reg_btn" class="btn btn-success" name="reg_user">Register</button>
                                    </div>
                                </div>  
                            </form>  
                        </div>	
                </div>
            </div>				
	</div>
</body>
</html>

