from keystoneauth1.identity import v3
from keystoneauth1 import session
from keystoneclient.v3 import client
import sys

auth = v3.Password(auth_url='http://192.168.30.5:5000/v3',
                   username='admin',
                   password='KDYc430Vp4Nsi1jiMbMypeCDviJTM016UynN6egp',
                   project_id='13de5928f71148a6a1f398d81e92f38d',
                   user_domain_id='default')
sess = session.Session(auth=auth)
ks = client.Client(session=sess)
domain_list= ks.domains.list()
domain_list_len=len(domain_list)
data=[]
name_string=""
for i in range(domain_list_len):
	value=domain_list[i].name
	data.append(value)
for i in range(domain_list_len):
	name_string=name_string+data[i]
        name_string=name_string+"."
print name_string

