<!DOCTYPE html>
<html lang="en">
<head>
  <title>NLE Sandbox</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
 <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
  <link href="custom.css" rel="stylesheet"/>
  <link href="ddsumenu.css" rel="stylesheet"/>
<html>
<body>
<div id="grosary_table" class="shadow-lg p-3 mb-5 bg-white rounded">
     <h3 style="padding-left:0px;color:green; text-align:center;">Glossary</h3></br>
                <p align="justify" style="font-size:14px;">
                   <p><strong>Administrator</strong>: The person responsible for installing, configuring, and managing an OpenStack cloud.</p>
                </p>
				 <p align="justify" style="font-size:14px;">
				<p><strong>Administrator</strong>: The person responsible for installing, configuring, and managing an OpenStack cloud.</p>
				</p>
				<p align="justify" style="font-size:14px;">
                <p><strong>Allocate</strong>: The process of taking a floating IP address from the address pool so it can be associated with a fixed IP on a guest VM instance.</p>
				</p>
				<p align="justify" style="font-size:14px;">
                <p><strong>Apache</strong>: The Apache Software Foundation supports the Apache community of open-source software projects. These projects provide software products for the public good.</p></p>
				<p align="justify" style="font-size:14px;">
           	    <p><strong>Apache License 2.0</strong>: All OpenStack core projects are provided under the terms of the Apache License 2.0 license.</p></p>
				<p align="justify" style="font-size:14px;">
       <p><strong>Apache Web Server</strong>: The most common web server software currently used on the Internet.</p></p>
	   <p align="justify" style="font-size:14px;">
       </p><strong>API Endpoint</strong>: The daemon, worker, or service that a client communicates with to access an API. API endpoints can provide any number of services, such as authentication, sales data, performance meters, Compute VM commands, census data, and so on.</p></p>
	   <p align="justify" style="font-size:14px;">
    </p><strong>Application</strong>: An application, also referred to as an application program or application software, is a computer software package that performs a specific function directly for an end user or, in some cases, for another application. An application can be self-contained or a group of programs. The program is a set of operations that runs the application for the user.</p></p>
<p align="justify" style="font-size:14px;">
    </p><strong>Application Programming Interface (API)</strong>: A collection of specifications used to access a service, application, or program. Includes service calls, required parameters for each call, and the expected return values.</p></p>
<p align="justify" style="font-size:14px;">
    </p><strong>Application Catalog Service (murano)</strong>: The project that provides an application catalog service so that users can compose and deploy composite environments on an application abstraction level while managing the application lifecycle.</p></p>
<p align="justify" style="font-size:14px;">
   </p><strong>Authentication</strong>: The process that confirms that the user, process, or client is really who they say they are through private key, secret token, password, fingerprint, or similar method.</p></p>
<p align="justify" style="font-size:14px;">
     </p><strong>Availability Zone</strong>: An Amazon EC2 concept of an isolated area that is used for fault tolerance. Do not confuse with an OpenStack Compute zone or cell.</p></p>
<p align="justify" style="font-size:14px;">
   </p><strong>Bandwidth</strong>: The amount of available data used by communication resources, such as the Internet. Represents the amount of data that is used to download things or the amount of data available to download.</p></p>
<p align="justify" style="font-size:14px;">
     <p><strong>Base Image</strong>: An OpenStack-provided image.</p></p>
<p align="justify" style="font-size:14px;">
   <p><strong>Block Device</strong>: A device that moves data in the form of blocks. These device nodes interface the devices, such as hard disks, CD-ROM drives, flash drives, and other addressable regions of memory.</p></p>
<p align="justify" style="font-size:14px;">
  </p><strong>Block Storage API</strong>: An API on a separate endpoint for attaching, detaching, and creating block storage for compute VMs.</p></p>
<p align="justify" style="font-size:14px;">
   </p><strong>Block Storage Service (Cinder)</strong>: The OpenStack service that implement services and libraries to provide ondemand, self-service access to Block Storage resources via abstraction and automation on top of other block storage devices.</p></p>
<p align="justify" style="font-size:14px;">
  </p><strong>Catalog</strong>: A list of API endpoints that are available to a user after authentication with the Identity service.</p></p>
<p align="justify" style="font-size:14px;">
   </p><strong>Catalog Service</strong>: An Identity service that lists API endpoints that are available to a user after authentication with the Identity service.</p></p>
<p align="justify" style="font-size:14px;">
   </p><strong>CentOS</strong>: A Linux distribution that is compatible with OpenStack.</p></p>
<p align="justify" style="font-size:14px;">
  </p><strong>Ceph</strong>: Massively scalable distributed storage system that consists of an object store, block store, and POSIXcompatible distributed file system. Compatible with OpenStack.</p></p>
<p align="justify" style="font-size:14px;">
   </p><strong>Cinder</strong>: Codename for Block Storage service.</p></p>
<p align="justify" style="font-size:14px;">
   </p><strong>CirrOS</strong>: A minimal Linux distribution designed for use as a test image on clouds such as OpenStack.</p></p>
<p align="justify" style="font-size:14px;">
</p><strong>Cloud Computing</strong>: A model that enables access to a shared pool of configurable computing resources, such as networks, servers, storage, applications, and services, that can be rapidly provisioned and released with minimal management effort or service provider interaction.</p></p>
<p align="justify" style="font-size:14px;">
</p><strong>Cloud Controller</strong>: Collection of Compute components that represent the global state of the cloud; talks to services, such as Identity authentication, Object Storage, and node/storage workers through a queue.</p></p>
<p align="justify" style="font-size:14px;">
</p><strong>Cloud Controller Node</strong>: A node that runs network, volume, API, scheduler, and image services. Each service may be broken out into separate nodes for scalability or availability.</p></p>
<p align="justify" style="font-size:14px;">
</p><strong>Compute Host</strong>: Physical host dedicated to running compute nodes.</p></p>
<p align="justify" style="font-size:14px;">
</p><strong>Compute Node</strong>: A node that runs the nova-compute daemon that manages VM instances that provide a wide range of services, such as web applications and analytics.</p></p>
<p align="justify" style="font-size:14px;">
</p><strong>Compute Service (Nova)</strong>: The OpenStack core project that implements services and associated libraries to provide massively-scalable, on-demand, self-service access to compute resources, including bare metal, virtual machines, and containers.</p></p>
<p align="justify" style="font-size:14px;">
</p><strong>Console Log</strong>: Contains the output from a Linux VM console in Compute.</p></p>
<p align="justify" style="font-size:14px;">
</p><strong>Container</strong>: Organizes and stores objects in Object Storage. Similar to the concept of a Linux directory but cannot be nested. Alternative term for an Image service container format.</p></p>
<p align="justify" style="font-size:14px;">
</p><strong>Core API</strong>: Depending on context, the core API is either the OpenStack API or the main API of a specific core project, such as Compute, Networking, Image service, and so on.</p></p>
<p align="justify" style="font-size:14px;">
<p><strong>Core Service</strong>: An official OpenStack service defined as core by DefCore Committee. Currently, consists of Block Storage service (cinder), Compute service (nova), Identity service (keystone), Image service (glance), Networking service (neutron), and Object Storage service (swift).</p></p>
</div>
</body>
</html>

