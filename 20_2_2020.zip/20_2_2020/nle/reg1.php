<?php
session_start();
        if (!isset($_SESSION['username'])) {
                $_SESSION['msg'] = "You must log in first";
                header("location: login.php");
        }
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
 <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
  <link href="custom.css" rel="stylesheet"/>


        <script>
           $(document).ready(function(){
               $("#appOnBoard").click(function()
                   {
                        $("#appOnBoard").css("text-decoration", "underline");
                        $("#dataDiv").load("aobg.php");
                 });
              });

           $(document).ready(function(){
             $("#oog").click(function()
                {
                    $("#oog").css("text-decoration", "underline");
                    $("#dataDiv").load("oog.php");
                });
            });
          $(document).ready(function(){
             $("#tog").click(function()
               {
                  $("#tog").css("text-decoration", "underline");
                  $("#dataDiv").load("tog.php");
               });
           });
       $(document).ready(function(){
           $("#reg").click(function()
               {
                  $("#reg").css("text-decoration", "underline");
                  $("#dataDiv").load("reg.php #rid");
               });
        });
        </script>
  </head>

<body>
  <?php if(isset($_SESSION['username'])){ ?>
   <?php include("del.php"); ?>
   <?php include("server.php"); ?>
  <div class="container id10">
       <div class="row row1">
             <div class="col-md-4 row_col1">
                 <div class="col1data" style="float:left;">
                          <figure>
                           <?php
                                $var=$_SESSION['username'];
                                $sql ="SELECT domain from users WHERE username='$var'";
                                $stmt = $conn->query($sql);
                                $row =$stmt->fetchObject();
                                $dom=$row->domain;
                                $dom="logo";
                            ?>
                            <img id="imid" style="align:center; float:left; height:26px;" src="<?php echo $dom ?>.jpg" alt="Cinque Terre">
                            <h3><figcaption>NEC</figcaption></h3>
                            </figure>
                   </div>
               </div>
             <div class="col-md-4 row_col2">
                 <div class="col2data"><h3 id="h11">Welcome To NLESANDBOX</h3></div>
             </div>
	              <div class="col-md-4 row_col3">
                         <div class="col3data" style="float:right;"> 
                          <figure>
                             <img style="float:right;" src="male.png" class="img-circle" alt="Cinque Terre" width="60" height="60">
                             <h3><figcaption><?php echo $_SESSION['username'] ?></figcaption></h3>
                          </figure>
                       </div>
                     </div>
		</div>
              <div class="row" style="padding-top:20px;">
             <div class="col-md-12">
              <nav class="navbar navbar-expand-md  navbar-dark bg-primary">
                   <a class="navbar-brand" href="newnav.php">HOME</a>

                  <ul class="navbar-nav">
                     <li class="nav-item">
                     <a class="nav-link" href="#"><strog>SandBoxPortal</strong></a>
                     </li>
                     <li class="nav-item dropdown">
                        <?php if($_SESSION['username']=='admin'){ ?><a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                        UserManagenet
                     </a><?php } ?>
                      <ul class="dropdown-menu">
                      <?php if($_SESSION['username']=='admin'){ ?><li class="dropdown-item w3-bar-item w3-button"><span data-toggle="modal" href="#myModal" >ViewUser</span>
                               
                       </li><?php } ?>
                      <?php if($_SESSION['username']=='admin'){ ?><li class="dropdown-item w3-bar-item w3-button">Create User</li><?php } ?> 
                      </ul>
                   </li>

    <!-- Dropdown -->
                  <li class="nav-item dropdown">
                      <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                        Documents
                     </a>
                    <ul class="dropdown-menu">
                      <li class="dropdown-item w3-bar-item w3-button" ><span id="appOnBoard" style="color:black; cursor:pointer; text-align:left;">Application Onboarding Guide</li></li>
                      <?php if($_SESSION['username']=='admin'){ ?><li class="dropdown-item w3-bar-item w3-button" ><span id="oog" style="color:black; cursor:pointer;">Openstack Onboarding Guide</li><?php } ?> 
                      <?php if($_SESSION['username']=='admin'){ ?><li class="dropdown-item w3-bar-item w3-button" ><span id="tog" style="color:black; cursor:pointer;">Tenant Onboarding Guide</li><?php } ?> 
                   </ul>
               </li>
            </ul>
                    <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
                    <ul class="navbar-nav" style="float:right;">
                    <li class="fa fa-sign-out" style="font-size:18px"><a href="logout.php" style="color:white;">Logout</a></li>
                       </ul>
                    </div>
        </nav>
   </div>
 </div>
      <div class="row row3" style="padding-top:25px;">
     <div  class="col-md-12">
               <div id="dataDiv" class="customDiv2">
                   <div style="padding-left:30%; padding-right:40px;">
                        <div class="panel-heading" style="padding-left:150px;">
                        <div class="panel-title">Register Here</div>
                        </div>
                        <div style="padding-right:350px;">
                        <form method="post" action="reg.php">
                             <div style="margin-bottom: 15px;" class="input-group">
                                        <span class="input-group-addon"><i class="glyphicon glyphicon-asterisk"></i></span>
                                        <input id="login-username" type="text" class="form-control" name="domain" value=""placeholder="Domain" required/>                                        
                             </div>
                             <div style="margin-bottom: 15px" class="input-group">
                                        <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                                        <input type="text" class="form-control" name="username" placeholder="User Name" >
                                    </div>
                              <div style="margin-bottom: 15px" class="input-group">
                                        <span class="input-group-addon"><i class="glyphicon glyphicon-envelope"></i></span>
                                        <input  type="email" class="form-control" name="email" placeholder="Email" /required/>
                                    </div>
                              <div style="margin-bottom: 15px" class="input-group">
                                        <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                                        <input type="password" class="form-control" name="password_1" placeholder="Password" required/>
                                    </div>
                              <div style="margin-bottom: 15px" class="input-group">
                                        <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                                        <input  type="password" class="form-control" name="password_2" placeholder="Confirm Password" required> 
                                    <?php if(!empty($pass_error)) { ?>
                                     <span>*<?php echo $pass_error ; ?></span>
                                     <?php } ?>
                                    </div>
                               <div style="margin-bottom: 15px" class="input-group">
                                        <span class="input-group-addon"><i class="glyphicon glyphicon-asterisk"></i></span>
                                        <input  type="text" class="form-control" name="project" placeholder="Project Name">
                                    </div>
                                <div style="margin-top:5px; float:right;" class="form-group">
                                    <div class="col-sm-12 controls">
                                      <button type="submit" id="reg_btn" class="btn btn-success" name="reg_user">Register</button>
                                    </div>
                        </form> 
                        </div>
                   </div>
               </div>
            </div>
           <!-- <div class="col-md-3">
               <div class="customDiv3">LINKbar3</div>
            </div>-->
      </div>
 </div>
</div>
<?php }
else header('location: login.php'); ?>
<body>
</html>




























