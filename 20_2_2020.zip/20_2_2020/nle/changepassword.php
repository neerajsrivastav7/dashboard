<?php
session_start();
        if (!isset($_SESSION['username'])) {
                $_SESSION['msg'] = "You must log in first";
                header("location: login.php");
        }
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>NLE Sandbox</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
 <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
  <link href="custom.css" rel="stylesheet"/>
  <link href="ddsumenu.css" rel="stylesheet"/>
    <style>
     .hower:hover {
  background-color: #555;
  color: white;
}
  .w3-btn,.w3-button{
text-align:left !important;
}


.error {color: #FF0000;}
     .form-control {
                border-color: #696969;
        min-height: 41px;
                box-shadow: none !important;
        }
    .form-control:focus {
                border-color: #5cd3b4;
        }
    .form-control, .btn {
        border-radius: 3px;
    }
        .signup-form {
                width: 500px;
                margin: 0 auto;
                padding: 30px 0;
        }
    .signup-form h2 {
                color: #333;
        margin: 0 0 30px 0;
                display: inline-block;
                padding: 0 30px 10px 0;
                border-bottom: 3px solid #5cd3b4;
    }
    .signup-form form {
                color: #999;
                border-radius: 3px;
        margin-bottom: 15px;
        background: #fff;
        box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
        padding: 30px;
    }
        .signup-form .form-group {
                margin-bottom: 20px;
        }
        .signup-form label {
                font-weight: normal;
                font-size: 13px;
        }
    .signup-form input[type="checkbox"] {
                margin-top: 2px;
        }
    .signup-form .btn {
        font-size: 16px;
        font-weight: bold;
                background: #5cd3b4;
                border: none;
                margin-top: 20px;
                min-width: 140px;
    }
        .signup-form .btn:hover, .signup-form .btn:focus {
                background: #41cba9;
        outline: none !important;
        }
    .signup-form a {
                color: #5cd3b4;
                text-decoration: underline;
        }
        .signup-form a:hover {
                text-decoration: none;
        }
    .signup-form form a {
                color: #5cd3b4;
                text-decoration: none;
        }
        .signup-form form a:hover {
                text-decoration: underline;
        }
</style>
        <script>
           $(document).ready(function(){
               $("#appOnBoard").click(function()
                   {
                        $("#appOnBoard").css("text-decoration", "underline");
                        $("#dataDiv").load("aobg.php #aobgd");
                 });
              });

           $(document).ready(function(){
             $("#oog").click(function()
                {
                    $("#oog").css("text-decoration", "underline");
                    $("#dataDiv").load("oog.php #oogd");
                });
            });
          $(document).ready(function(){
             $("#tog").click(function()
               {
                  $("#tog").css("text-decoration", "underline");
                  $("#dataDiv").load("tog.php #togd");
               });
           });
        $(document).ready(function(){
           $("#gos").click(function()
               {
                  $("#gos").css("text-decoration", "underline");
                  $("#dataDiv").load("Grosary.php #grosary_table");
               });
        });         
        </script>
  </head>

<body>
  <?php if(isset($_SESSION['username'])){ ?>
  <div class="container id10">
      <?php include('template.php'); ?>
      <div class="row row3" style="padding-top:25px;">
      <div  class="col-md-12">
               <div id="dataDiv">
                  <div style="text-align:center">
                      <?php
                   $oldpasswordErr = $passwordErr = $passupdate="";
                   $password_1 =  $password_2 = $password_3="";
                   $f1 = $f2 = $f = $f4 = $f5 = $f6=0;
                    if ($_SERVER["REQUEST_METHOD"] == "POST") {
                    $password_1=$_POST["password_1"];
                    $password_2=$_POST["password_2"];
                    $password_3=$_POST["password_3"];
                    if ($password_2!=$password_3) {
                        $passwordErr = "Must match the previous entry";
                   }
                   else
                    {
                       $f1=1;
                    }
					$Domain=$_SESSION['domain'];
					$UserName=$_SESSION['username'];
					$old_password=$password_1;
					$new_password=$password_2;
					if($f1==1)
	                                 {				 
					      $return_String=exec("python password_changed.py $UserName $Domain $old_password $new_password");
					      if($return_String=="true")
					        {
					           $passupdate="Password updated";
                                                   header('location:newnav.php');   
					        }
						   else 
						    {
							   $oldpasswordErr="Old Password is Wrong";
							}
					   }
			}

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>
<div class="signup-form">
    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>" method="post" class="form-horizontal">
                <div class="col-xs-8 col-xs-offset-4">
                        <h2>Reset Password</h2>
                </div>
                <div>
                        <span ><h3> <?php echo $passupdate;?> </h2></span>
               </div>
              <div class="form-group">
                        <label class="control-label col-xs-4">Old Password</label>
                        <div class="col-xs-8">
                <input type="Password" class="form-control" name="password_1" required="required">
            </div>
        </div>
       <span class="error"> <?php echo $oldpasswordErr;?></span>
        <div class="form-group">
                        <label class="control-label col-xs-4">New Password</label>
                        <div class="col-xs-8">
                <input type="password" class="form-control" name="password_2" required="required">
            </div>
        </div>
                <div class="form-group">
                        <label class="control-label col-xs-4">Confirm Password</label>
                        <div class="col-xs-8">
                <input type="password" class="form-control" name="password_3" required="required">
            </div>
           <span class="error"> <?php echo $passwordErr;?></span>
        </div>
                <div class="form-group">
                        <div class="col-xs-8 col-xs-offset-4">
                                <button type="submit" class="btn btn-primary btn-lg">Reset Password</button>
                        </div>
                </div>
    </form>
<!--    <div class="text-center">Already have an account? <a href="#">Login here</a></div>-->
</div>
  </div>
                  </div>
               </div>
            </div>
           <!-- <div class="col-md-3">
               <div class="customDiv3">LINKbar3</div>
            </div>-->
      </div>
</div>
</div>
<?php }
else header('location: login.php'); ?>
<body>
</html>

