<?php
session_start();
        if (!isset($_SESSION['username'])) {
                $_SESSION['msg'] = "You must log in first";
                header("location: login.php");
        }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>NLE Sandbox</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
 <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
  <link href="custom.css" rel="stylesheet"/>
  <link href="ddsumenu.css" rel="stylesheet"/>
  <style>
    .hower:hover {
  background-color: #555;
  color: white;
}
  .w3-btn,.w3-button{
   text-align:left !important;
} 
  </style>
        <script>
            $(document).ready(function(){
               $("#appOnBoard").click(function()
                   {
                        $("#appOnBoard").css("text-decoration", "underline");
                        $("#dataDiv").load("aobg.php #aobgd");
                 });
              });

           $(document).ready(function(){
             $("#oog").click(function()
                {
                    $("#oog").css("text-decoration", "underline");
                    $("#dataDiv").load("oog.php #oogd");
                });
            });
          $(document).ready(function(){
             $("#tog").click(function()
               {
                  $("#tog").css("text-decoration", "underline");
                  $("#dataDiv").load("tog.php #togd");
               });
           });
       $(document).ready(function(){
           $("#reg").click(function()
               {
                  $("#reg").css("text-decoration", "underline");
                  $("#dataDiv").load("reg.php #rid");
               });
        });
        $(document).ready(function(){
           $("#gos").click(function()
               {
                  $("#gos").css("text-decoration", "underline");
                  $("#dataDiv").load("Grosary.php #grosary_table");
               });
        });
        </script>
  </head>

<body>
  <?php if(isset($_SESSION['username'])){ ?>
  <div class="container id10">
      <?php include('template.php'); ?>
      <div class="row row3" style="padding-top:25px;">
     <div  class="col-md-12">
               <div id="dataDiv" class="customDiv2">
                 <h1 style="text-align:center;">User Details</h1>
                 <div id="did" class="shadow-lg p-3 mb-5 bg-white rounded">
                    <?php
                       $domain_name=exec("python domain_name.py");
                       $domain_array=explode (".", $domain_name);
                       $domain_array_len=sizeof($domain_array); 
                       for($i=0;$i<$domain_array_len-1;$i++)
                          {
                            ?> <h1> <?php echo $domain_array[$i]; ?></h1></br>
                               <div>
                                  <table class="table">
                                       <thead>
                                            <tr>
                                               <th>UserName</th>
                                               <th>Project</th>
                                               <th>Email</th>
                                            </tr>
                                        </thead>
                                        <?php 
                                        $user_String=exec("python Domain_User_List.py $domain_array[$i]");
                                        $domain_user_array=explode (".", $user_String);
                                        $domain_user_array_len=sizeof($domain_user_array);
                                        for($x=0;$x<$domain_user_array_len-1;$x++)
                                            {
 						 $return_string=exec("python KeyStoen.py  $domain_user_array[$x]");
                                                 $project_arr = explode('.', $return_string);
                                                 $lenth = sizeof($project_arr);
                                                 for ($y= 0; $y<$lenth-1; $y++) { ?>
                                                        <tbody>
                                                            <tr>
                                                             <td><?php echo $domain_user_array[$x]; ?></td>
                                                             <td><?php echo $project_arr[$y]; ?></td>
                                                             <td><?php $return_string=exec("python get_email.py $domain_user_array[$x]");
                                                               echo $return_string;  ?></td>
                                                            </tr>
                                                       </tbody>
                                                   <?php
                                                     }
                                              
                                            }
                                        ?>
                                  </table>    
                               </div>
                          <?php
                          }
                    ?>
                 </div>
               </div>
            </div>
      </div>
</div>
</div>
<?php }
else header('location: login.php'); ?>
<body>
</html>
