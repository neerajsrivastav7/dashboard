<DOCTYPE html>
<html>
<head>
        <title>Login</title>
        <link rel="stylesheet" type="text/css" href="style.css">
        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
</head>
<body>
         <?php
                   include('connection.php');
                   $emailErr ="";
                   $email ="";
                   $f1 =0;
                   if ($_SERVER["REQUEST_METHOD"] == "POST") {
                      $email=$_POST["email"];
                      $sql ="SELECT password,email from users WHERE email='$email'";
                      $stmt = $conn->query($sql);
                      $row =$stmt->fetchObject();
                      $email_1=$row->email;
                      $pass=$row->password;
                      if($email==$email_1)
                       {
                       $to=$email_1;
                       $subject = "Recover Password";
                       $message = "<b>use $pass  to login</b>";
                      # $message .=  echo $pass;
                       $header = "From:abc@somedomain.com \r\n";
                       $header .= "Cc:afgh@somedomain.com \r\n";
                       $header .= "MIME-Version: 1.0\r\n";
                       $header .= "Content-type: text/html\r\n";
                       $retval = mail($to,$subject,$message,$header);
                       if( $retval == true )
                       $emailErr = "Message sent successfully to $email";
                       }
                      else
                        {
                         $emailErr = "Email does not  exits";
                        }

                   }
         ?>

        <div class="header">
               <h2><strong>NLE Sandbox</strong></h2>
        </div>

        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">

               
                <div class="input-group">
                        <label>Enter registered Email</label>
                        <input type="email" name="email" >
                </div>
                <div class="input-group">
                    <p ><?php echo $emailErr;?></p>
                </div>

                <div class="input-group">
                        <button type="submit" class="btn" name="login_user">Recover</button>
                        <a href="login.php" class="btn">Login</a>
                </div>
                <!--<p>
                        Not yet a member? <a href="register.php">Sign up</a>
                </p>-->
        </form>


