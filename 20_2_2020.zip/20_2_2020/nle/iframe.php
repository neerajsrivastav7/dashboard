CTYPE html>
<html>
<body>

<iframe id="myFrame" src="http://192.168.30.5/auth/login/?next=/" style="height:380px;width:100%"></iframe>

<p>Click the "Tryit" button to hide the first H1 element in the iframe (another document).</p>

<button onclick="myFunction()">Try it</button>

<script>
function myFunction() {
  var iframe = document.getElementById("myFrame");
  var elmnt = iframe.contentWindow.document.getElementsByTagName("H1")[0];
  elmnt.style.display = "none";
}
</script>

</body>
</html>


