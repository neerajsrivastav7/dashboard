from keystoneauth1.identity import v3
from keystoneauth1 import session
from keystoneclient.v3 import client
import sys
UserName=sys.argv[1]
old_password=sys.argv[3]
UserDomain=sys.argv[2]
new_password=sys.argv[4]
auth = v3.Password(auth_url='http://192.168.30.5:5000/v3',
                   username=UserName,
                   password=old_password,
                   user_domain_name=UserDomain)
sess = session.Session(auth=auth)
ks = client.Client(session=sess)
try:
	password_changed=ks.users.update_password(old_password, new_password)
	print "true"
except:
	print "false"
