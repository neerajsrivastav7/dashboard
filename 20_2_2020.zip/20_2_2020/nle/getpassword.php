
<?php
// Start the session
session_start();
?>
<!DOCTYPE html>
<html>
<body>

<?php
// Set session variables
echo $_SESSION["username"] ;
echo $_SESSION["password"] ;
echo $_SESSION["domain"] ;
?>
</body>
</html>
