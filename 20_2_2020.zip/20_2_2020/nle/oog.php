<?php
        session_start();
//        echo $_SESSION['username'];
        if (!isset($_SESSION['username'])) {
                $_SESSION['msg'] = "You must log in first";
                header("location: login.php");
        }

/*      if (isset($_GET['logout'])) {
                session_destroy();
                unset($_SESSION['username']);
                header("location: login.php");
        }*/

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>NLE SANDBOX</title>
     <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
              <div id="oogd" class="shadow-lg p-3 mb-5 bg-white rounded">
               <h3 style="padding-left:0px;color:green; text-align:center;">Description of Openstack Onboarding Guide</h3></br>
                <p align="justify" style="font-size:14px;">
                    This document provides instructions for performing a Kolla-Ansible based OpenStack installation on Ubuntu 16.04 in a production environment including the node details. It covers the installation of multi node OpenStack with Queens release, and configuring following openstack services:
                </p>
     <ul>
        <li style="float:left; font-size:14px;"> Block Storage (Cinder) </li></br>
        <li style="float:left; font-size:14px;"> Compute (Nova)</li></br>
        <li style="float:left; font-size:14px;"> Dashboard (Horizon)</li></br>
       <li style="float:left; font-size:14px;"> Identity (Keystone)</li></br>
       <li style="float:left; font-size:14px;"> Image (Glance)</li></br>
        <li style="float:left; font-size:14px;"> Networking (Neutron)</li></br>
        <li style="float:left; font-size:14px;"> Dashboard based application deployment (Murano)</li></br>
        <li style="float:left; font-size:14px;"> Orchestration (Heat)</li></br>
    </ul>
<p align="justify" style="font-size:14px;">
    It is intended for DevOps/Admin guys.
</p>
                 <a href="Openstack_Deployment_Guide_v0.2.docx" target="_blank" style="color:green;">Download Document Here</a>

 </div>
</body>
</html>


