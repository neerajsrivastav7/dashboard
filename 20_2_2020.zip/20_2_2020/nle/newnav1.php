<?php
session_start();
        if (!isset($_SESSION['username'])) {
                $_SESSION['msg'] = "You must log in first";
                header("location: login.php");
        }
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>NLE Sandbox</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
 <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
  <link href="custom.css" rel="stylesheet"/>
  <style>
    .hower:hover {
  background-color: #555;
  color: white;
}
  </style>
        <script>
           $(document).ready(function(){
               $("#appOnBoard").click(function()
                   {
                        $("#appOnBoard").css("text-decoration", "underline");
                        $("#dataDiv").load("aobg.php #aobgd");
                 });
              });

           $(document).ready(function(){
             $("#oog").click(function()
                {
                    $("#oog").css("text-decoration", "underline");
                    $("#dataDiv").load("oog.php #oogd");
                });
            });
          $(document).ready(function(){
             $("#tog").click(function()
               {
                  $("#tog").css("text-decoration", "underline");
                  $("#dataDiv").load("tog.php #togd");
               });
           });
       $(document).ready(function(){
           $("#reg").click(function()
               {
                  $("#reg").css("text-decoration", "underline");
                  $("#dataDiv").load("reg.php #rid");
               });
        });
        $(document).ready(function(){
           $("#duser").click(function()
               {
                  $("#duser").css("text-decoration", "underline");
                  $("#dataDiv").load("del.php #did");
               });
        });
        </script>
  </head>

<body>
  <?php if(isset($_SESSION['username'])){ ?>
  <div class="container id10">
      <?php include('template.php'); ?>
      <div class="row row3" style="padding-top:25px;">
     <div  class="col-md-12">
               <div id="dataDiv" class="customDiv2">
                <h3 style="padding-left:0px;color:green; text-align:center;">Introduction to Sandbox</h3></br>
                <p align="justify" style="font-size:14px;">
The notion of connecting every electronic, sensor or actuator device to the internet and making them communicate and exchange data has set the World on the beginning of another revolution. Convergence of various technologies together like Machine Learning, Sensors, Embedded systems, real-time analytics have given wings to the idea of Internet Of Things (or IOT). Only through IOT, one can think of smart cities where smart parking, smart automobiles, smart temperature and pollution check systems, smart lighting systems, etc. exist.
</p>
               <p align="justify" style="font-size:14px;">
                 To ease and accelerate the routine processes, smart devices can step-in. Smart devices can inform a driver about a broken or under-construction road beforehand, smart devices can tell where a car parking slot is available in the parking area, smart devices can serve as query system of an environment and much more.
              </p>
               <P align="justify" style="font-size:14px;">
                 For such an infrastructure or environment, there is a list of requirements like network connectivity, power enabled data sensors and actuators, computing devices with embedded or remote computing systems, data managers etc
               </P>
               <P align="justify" style="font-size:14px;">
                 This is where IOT Sandbox Solution steps in. IOT Sandbox solution is a cloud service dedicated for IOT data management that provides service at both PAAS and IAAS level. The platform applications provided by Sandbox can actually interact with the smart devices and manage the entire lifecycle of data using the cloud infrastructure from sensors to the actuators.
              </P>
               </div>
            </div>
           <!-- <div class="col-md-3">
               <div class="customDiv3">LINKbar3</div>
            </div>-->
      </div>
</div>
</div>
<?php }
else header('location: login.php'); ?>
<body>
</html>

