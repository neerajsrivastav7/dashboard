<?php
   $var="DLC_member4";
   $user_name=$var;
   $results =exec("openstack role assignment list --user $user_name --role _member_  -c Project --names -f value  > project.txt");
 $arr=array();
 $i=0;
if ($fh = fopen('project.txt', 'r')) {
    while (!feof($fh)) {
        $line = fgets($fh);
        $possition=strpos($line,"@");
        $line= substr($line,0,$possition);
        $arr[$i]=$line;
        $i=$i+1;   
    }
    fclose($fh);
 }
  $Array_len=$i; 
 ?>
