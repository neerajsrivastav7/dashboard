<!doctype html>
<head>
<title>Forget password</title>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
<script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<style>
  .form-gap {
    padding-top: 70px;
}
</style>
</head>
 <body>
            <?php
                   $emailErr ="";
                   $email ="";
                   $f1 =0;
                   if ($_SERVER["REQUEST_METHOD"] == "POST") {
                      $email=$_POST["email"];
                      $username=$_POST["username"];
                      $return_string=exec("python get_email.py $username");
                      if($email==$return_string)
                       {
                       $pass=exec("python keystone_program1.py  $username");
                       if($pass=="false")
                         {
                            $emailErr = "Username or Email does not  exits";
                         }
                       else
                         {
                             $to=$email;
                             $subject = "Recover Password";
                             $message = "<b>use $pass to login</b>";
                             # $message .=  echo $pass;
                            $header = "From:abc@somedomain.com \r\n";
                            $header .= "Cc:afgh@somedomain.com \r\n";
                            $header .= "MIME-Version: 1.0\r\n";
                            $header .= "Content-type: text/html\r\n";
                            $retval = mail($to,$subject,$message,$header);
                            if( $retval == true )
                            $emailErr = "Password sent successfully to $email";
                          }
                      }
                      else
                        {
                         $emailErr = "Email does not  exits";
                        }
                   }
         ?>
 <div class="form-gap"></div>
<div class="container">
	<div class="row">
		<div class="col-md-4 col-md-offset-4">
            <div class="panel panel-default">
              <div class="panel-body">
                <div class="text-center">
                  <h3><i class="fa fa-lock fa-4x"></i></h3>
                  <h2 class="text-center">Forgot Password?</h2>
                  <p>You can reset your password here.</p>
                  <div class="panel-body">
                    <div>
                        <span ><h5> <?php echo $emailErr; ?> </h5></span>                        
                    </div>
                    <form id="register-form" role="form" autocomplete="off" class="form" method="post" actipn="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>">
    
                      <div class="form-group">
                         <div class="input-group">
                          <span class="input-group-addon"><i class="glyphicon glyphicon-envelope color-blue"></i></span>
                          <input id="username" name="username" placeholder="username" class="form-control"  type="username" required/>
                        </div>
                      </div>
                        <div class="input-group">
                          <span class="input-group-addon"><i class="glyphicon glyphicon-envelope color-blue"></i></span>
                          <input id="email" name="email" placeholder="email address" class="form-control"  type="email" required/>
                        </div>
                      </div>
                      <div class="form-group">
                        <input name="recover-submit" class="btn btn-lg btn-primary btn-block" value="Reset Password" type="submit">
                         <button type="button" class="btn btn-lg btn-primary btn-block"><a href="login.php" style="color:white;">Login</a></button>                         
                      </div>
                    </form>
                    
                  </div>
                </div>
              </div>
            </div>
          </div>
	</div>
</div>
</body>
</html>
