   <?php
    include('connection.php');
     
    $edittable=$_POST['selector'];
    $N = count($edittable);
    for($i=0; $i < $N; $i++)
    {
    	$result = $conn->prepare("DELETE FROM users WHERE username= :memid");
    	$result->bindParam(':memid', $edittable[$i]);
    	$result->execute();
    }
    header("location: newnav.php");
    ?>

