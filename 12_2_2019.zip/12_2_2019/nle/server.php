<?php
        session_start();
        $username = "";
        $email= "";
        $pass_error = "";
        $errors = array();
        $_SESSION['success'] = "";
        if (isset($_POST['login_user'])) {
                $Domain=$_POST["domain"];
                $myEmail=$_POST["email"];
                $username=$_POST['username'];
                $password = $_POST['password'];
                $return_string=exec("python Get_token.py $username $password $Domain");
		         if($return_string=="true")
                                {
                                      $_SESSION['username']=$username;
				       $_SESSION['domain']=$Domain;
				        header('location: newnav.php');
	                        }
                            else {
                                array_push($errors, "Wrong username/password combination");
                        }
                }

?>

