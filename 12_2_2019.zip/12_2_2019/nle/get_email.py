from keystoneauth1.identity import v3
from keystoneauth1 import session
from keystoneclient.v3 import client
import sys

auth = v3.Password(auth_url='http://192.168.30.5:5000/v3',
                   username='admin',
                   password='KDYc430Vp4Nsi1jiMbMypeCDviJTM016UynN6egp',
                   project_id='13de5928f71148a6a1f398d81e92f38d',
                   user_domain_id='default')
sess = session.Session(auth=auth)
ks = client.Client(session=sess)
users = ks.users.list()
given_users=sys.argv[1]
user_email=""
try:
	i=0
	while i < len(users):
        	if given_users == str(users[i].name):
                	break
        	i=i+1
	user_email = str(users[i].email)
	print user_email
except:
	print "false"

