<?php
session_start();
//        echo $_SESSION['username'];
        if (!isset($_SESSION['username'])) {
                $_SESSION['msg'] = "You must log in first";
                header("location: login.php");
        }

/*      if (isset($_GET['logout'])) {
                session_destroy();
                unset($_SESSION['username']);
                header("location: login.php");
				<li id="menu-item-135007" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-135007"><a href="">C++</a></li>
        }*/

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>NLE SANDBOX</title>
   <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <link href="custom.cFashionss" rel="stylesheet"/>
  <script>
      $(document).ready(function(){
        $("#appOnBoard").click(function()
           {
               $("#appOnBoard").css("text-decoration", "underline");
                $("#dataDiv").load("aobg.php");
            });
});

      $(document).ready(function(){
        $("#oog").click(function()
           {
               $("#oog").css("text-decoration", "underline");
                $("#dataDiv").load("oog.php");
            });
});
 $(document).ready(function(){
        $("#tog").click(function()
           {
               $("#tog").css("text-decoration", "underline");
                $("#dataDiv").load("tog.php");
            });
});
 $(document).ready(function(){
        $("#reg").click(function()
           {
               $("#reg").css("text-decoration", "underline");
                $("#dataDiv").load("reg.php #rid");
            });
});
 $(document).ready(function(){
        $("#reg_btn").click(function()
           {

                $("#dataDiv").load("reg.php #rid");
            });
});
</script>
</head>
<body>
 <?php include('del.php') ?>
  <?php if(isset($_SESSION['username'])){ ?>
      <div class="container id10">
            <div class="row">
                    <div class="col-xs-4">
                         <div class="bid1" style="padding-top:30px;">
                             <ul class="nav navbar-left limage">
                           <?php
                                include('connection.php');
                                $var=$_SESSION['username'];
                                $sql ="SELECT domain from users WHERE username='$var'";
                                $stmt = $conn->query($sql);
                                $row =$stmt->fetchObject();
                                $dom=$row->domain;
                            ?>
                            <li> <img id="imid" style="align:center; float:left; height:26px;" src="images/<?php echo $dom ?>.png" alt="Cinque Terre"></li>
                        </ul>
                          </div>
                   </div>
                   <div class="col-xs-4">
                         <div class=bid2><h3 id="h11">Welcome To NLESANDBOX</h3></div>
                   </div>
                   <div class="col-xs-4">
                        <div class="bid3">
                        <ul class="nav navbar-right rimage">
                         <img id="imid" style="align:center; float:right"src="male.png" class="img-circle" alt="Cinque Terre" width="60" height="60"></li>
                     <li> <h3><?php echo $_SESSION['username'] ?> </h3></li>
                     </ul>
                     </div>
               </div>
     </div >
       <div class="row srow shadow-lg p-3 mb-5 bg-white rounded">
        <nav class="navbar navbar-inverse">
                      <ul class="nav navbar-nav">
                        <li class="active"><a href="nav.php">Home</a></li>
                         <?php if($_SESSION['username']=='admin'){ ?> <li style="padding-top: 15px; color:white;cursor:pointer;"><span data-toggle="modal" href="#myModal" >ViewUser</span>  </li> <?php } ?>
                      <?php if($_SESSION['username']=='admin'){ ?> <li style="padding-top:15px; padding-left:10px;color:white; cursor:pointer;"><span id="reg" style="color:white; cursor:pointer;">CreateUser</span></li><?php } ?>
                     </ul>
                        <ul class="nav navbar-nav navbar-right">
                            <li style="padding-right:50px; color:white;"><a href="logout.php"><span class="glyphicon glyphicon-log-out" ></span>Logout</a></li>
                       </ul>
              </div>
       </nav>
       <div class="row id">
            <div class="col-md-3" style="padding-top:80px;">
               <div class="customDiv1">
                    <div class="list-group">
                 <!--   <a class="list-group-item active">Document</a>-->
                    <ul class="list-group">
                       <li class="list-group-item list-group-item-info active"><a style="color:white;" href="http://192.168.30.5/auth/login/?next=/" target="_blank">SandBoxPortal</a></li>
                        <li class="list-group-item"> <span id="appOnBoard" style="color:black; cursor:pointer; text-align:left;">Application Onboarding Guide</li>
             <?php if($_SESSION['username']=='admin'){ ?> <li class="list-group-item"><span id="oog" style="color:black; cursor:pointer;">Openstack Onboarding Guide</li><?php } ?>
                   <?php if($_SESSION['username']=='admin'){ ?> <li class="list-group-item"><span id="tog" style="color:black; cursor:pointer;">Tenant Onboarding Guide</a></li><?php } ?>
                  </ul>
                   </div>
               </div>
            </div>
           <div class="col-md-9">
               <div id="dataDiv" class="customDiv2">
                <h3 style="padding-left:0px;color:green;">Introduction to sandbox</h3></br>
                <p align="justify" style="font-size:14px;">
The notion of connecting every electronic, sensor or actuator device to the internet and making them communicate and exchange data has set the World on the beginning of another revolution. Convergence of various technologies together like Machine Learning, Sensors, Embedded systems, real-time analytics have given wings to the idea of Internet Of Things (or IOT). Only through IOT, one can think of smart cities where smart parking, smart automobiles, smart temperature and pollution check systems, smart lighting systems, etc. exist.
</p>
               <p align="justify" style="font-size:14px;">
                 To ease and accelerate the routine processes, smart devices can step-in. Smart devices can inform a driver about a broken or under-construction road beforehand, smart devices can tell where a car parking slot is available in the parking area, smart devices can serve as query system of an environment and much more.
              </p>
               <P align="justify" style="font-size:14px;">
                 For such an infrastructure or environment, there is a list of requirements like network connectivity, power enabled data sensors and actuators, computing devices with embedded or remote computing systems, data managers etc
               </P>
               <P align="justify" style="font-size:14px;">
                 This is where IOT Sandbox Solution steps in. IOT sandbox solution is a cloud service dedicated for IOT data management that provides service at both PAAS and IAAS level. The platform applications provided by Sandbox can actually interact with the smart devices and manage the entire lifecycle of data using the cloud infrastructure from sensors to the actuators.
              </P>
               </div>
            </div>
           <!-- <div class="col-md-3">
               <div class="customDiv3">LINKbar3</div>
            </div>-->
      </div>
   <!-- <div class="row id">
            <div class="col-md-12">
               <div class="customDiv4">
                <h2>NEC Laboratories Europe GmbH</h2>
               </div>
            </div>
    </div>-->
   </div>
<?php }
else header('location: login.php'); ?>
</body>
</html>

