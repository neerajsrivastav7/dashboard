<!DOCTYPE html>
<html>
<body>

<?php
session_start();
include('connection.php');
$var=$_SESSION['username'];
$sql ="SELECT domain from users WHERE username='$var'";
$stmt = $conn->query($sql);
       $row =$stmt->fetchObject();
       $dom=$row->domain;
   echo $dom;
?> 

</body>
</html>
