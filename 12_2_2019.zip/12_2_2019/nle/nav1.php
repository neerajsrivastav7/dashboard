<?php
         session_start();
//        echo $_SESSION['username'];
        if (!isset($_SESSION['username'])) {
                $_SESSION['msg'] = "You must log in first";
                header("location: login.php");
        }

/*      if (isset($_GET['logout'])) {
                session_destroy();
                unset($_SESSION['username']);
                header("location: login.php");
                                <li id="menu-item-135007" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-135007"><a href="">C++</a></li>
        }*/

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
  <link href="custom.css" rel="stylesheet"/>
  <script>
      $(document).ready(function(){
        $("#appOnBoard").click(function()
           {
               $("#appOnBoard").css("text-decoration", "underline");
                $("#dataDiv").load("aobg.php #aobg1");
            });
});

      $(document).ready(function(){
        $("#oog").click(function()
           {
               $("#oog").css("text-decoration", "underline");
                $("#dataDiv").load("oog.php");
            });
});
 $(document).ready(function(){
        $("#tog").click(function()
           {
               $("#tog").css("text-decoration", "underline");
                $("#dataDiv").load("tog.php");
            });
});
 $(document).ready(function(){
        $("#reg").click(function()
           {
               $("#reg").css("text-decoration", "underline");
                $("#dataDiv").load("reg.php #rid");
            });
});
 $(document).ready(function(){
        $("#reg_btn").click(function()
           {

                $("#dataDiv").load("reg.php #rid");
            });
});
</script>
</head>

<body>

 <?php include('del.php') ?>
  <?php if(isset($_SESSION['username'])){ ?>
    <div class="container id10">
        <div class="row">
            <div class="col-xs-4">
                <div class="bid1" style="padding-top:30px;">
                    <ul class="nav navbar-left limage">
                           <?php
                                include('connection.php');
                                $var=$_SESSION['username'];
                                $sql ="SELECT domain from users WHERE username='$var'";
                                $stmt = $conn->query($sql);
                                $row =$stmt->fetchObject();
                                $dom=$row->domain;
                            ?>
                            <li> <img id="imid" style="align:center; float:left; height:26px;" src="images/<?php echo $dom ?>.png" alt="Cinque Terre"></li>
                    </ul>
                </div>
            </div>
            <div class="col-xs-4">
                <div class=bid2><h3 id="h11">Welcome To NLESANDBOX</h3></div>
            </div>
            <div class="col-xs-4">
                <div class="bid3">
                    <ul class="nav navbar-right rimage">
                        <li><img id="imid" style="align:center; float:right"src="male.png" class="img-circle" alt="Cinque Terre" width="60" height="60"></li>
						<li> <h3><?php echo $_SESSION['username'] ?> </h3></li>
                    </ul>
                </div>
            </div>
		</div >
        <div class="row" style="padding-top:20px;">
             <div class="col-md-12">
              <nav class="navbar navbar-expand-md bg-dark navbar-dark">
                   <a class="navbar-brand" href="#">Logo</a>

                  <ul class="navbar-nav">
                     <li class="nav-item">
                     <a class="nav-link" href="#">Link 1</a>
                     </li>
                     <li class="nav-item">
                    <a class="nav-link" href="#">Link 2</a>
                   </li>

    <!-- Dropdown -->
                  <li class="nav-item dropdown">
                      <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                        Dropdown link
                     </a>
                    <div class="dropdown-menu">
                      <a class="dropdown-item" href="#">Link 1</a>
                      <a class="dropdown-item" href="#">Link 2</a>
                      <a class="dropdown-item" href="#">Link 3</a>
                   </div>
               </li>
            </ul>
        </nav>
   </div>
 </div>
		<div class="row id">
            <div class="col-md-3" style="padding-top:80px;">
				<div class="customDiv1">
                    <div class="list-group">
					<!--   <a class="list-group-item active">Document</a>-->
						<ul class="list-group">
						   <li class="list-group-item list-group-item-info active"><a style="color:white;" href="http://192.168.30.5/auth/login/?next=/" target="_blank">SandBoxPortal</a></li>
						   <li class="list-group-item"> <span id="appOnBoard" style="color:black; cursor:pointer; text-align:left;">Application Onboarding Guide</li>
							<?php if($_SESSION['username']=='admin'){ ?> <li class="list-group-item"><span id="oog" style="color:black; cursor:pointer;">Openstack Onboarding Guide</li><?php } ?>
							<?php if($_SESSION['username']=='admin'){ ?> <li class="list-group-item"><span id="tog" style="color:black; cursor:pointer;">Tenant Onboarding Guide</a></li><?php } ?>
						</ul>
                   </div>
				</div>
            </div>			
		<div class="col-md-9">
              <div id="dataDiv" class="customDiv2">
                <h3>Introduction to sandbox</h3></br>
                <p align="justify" style="font-size:14px;">
					The notion of connecting every electronic, sensor or actuator device to the internet and making them communicate and exchange data has set the World on the beginning of another revolution. Convergence of various technologies together like Machine Learning, Sensors, Embedded systems, real-time analytics have given wings to the idea of Internet Of Things (or IOT). Only through IOT, one can think of smart cities where smart parking, smart automobiles, smart temperature and pollution check systems, smart lighting systems, etc. exist.
				</p>
				<p align="justify" style="font-size:14px;">
                 To ease and accelerate the routine processes, smart devices can step-in. Smart devices can inform a driver about a broken or under-construction road beforehand, smart devices can tell where a car parking slot is available in the parking area, smart devices can serve as query system of an environment and much more.
				</p>
				<P align="justify" style="font-size:14px;">
                 For such an infrastructure or environment, there is a list of requirements like network connectivity, power  data sensors and actuators, computing devices with embedded or remote computing systems, data managers etc
				</P>
				<P align="justify" style="font-size:14px;">
                 This is where IOT Sandbox Solution steps in. IOT sandbox solution is a cloud service dedicated for IOT data management that provides service at both PAAS and IAAS level. The platform applications provided by Sandbox can actually interact with the smart devices and manage the entire lifecycle of data using the cloud infrastructure from sensors to the actuators.
				</P>
               </div>
            </div>
           <!-- <div class="col-md-3">
               <div class="customDiv3">LINKbar3</div>
            </div>-->
		</div>
   <!-- <div class="row id">
            <div class="col-md-12">
               <div class="customDiv4">
                <h2>NEC Laboratories Europe GmbH</h2>
               </div>
            </div>
    </div>-->
	</div>

<?php }
else header('location: login.php'); ?>

</body>
</html>

