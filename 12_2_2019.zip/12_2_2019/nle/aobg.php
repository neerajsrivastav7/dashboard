<?php
        session_start();
//        echo $_SESSION['username'];
        if (!isset($_SESSION['username'])) {
                $_SESSION['msg'] = "You must log in first";
                header("location: login.php");
        }

/*      if (isset($_GET['logout'])) {
                session_destroy();
                unset($_SESSION['username']);
                header("location: login.php");
        }*/

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>NLE SANDBOX</title>
       <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
              <div id="aobgd" class="shadow-lg p-3 mb-5 bg-white rounded" id="aobg1">
                <h3 style="color:green; text-align:center;">Description of Application Onboarding Guide</h3></br>
                <p align="justify" style="font-size:14px;">
                  This document provides instructions for performing single click orchestration of instances of Fiware Generic Enablers on cloud environment. It is intended to be used for the automated orchestration of following instances with Fiware Generic Enablers (GEs) running at specific endpoints using Sandbox Orchestration Manager:</p>
              <ul>
                 <li style="float:left; font-size:14px;">Orion over Docker</li></br>
                <li  style="float:left; font-size:14px;">IOT Agent over Docker</li></br>
                <li  style="float:left; font-size:14px;">Fogflow over Docker</li></br>
                <li  style="float:left; font-size:14px;">Next Generation Broker</li></br>
             </ul>
 <p align="justify" style="font-size:14px;">
The document covers a brief introduction about Sandbox Orchestration Manager, then detailed instructions for application onboarding.
                </P>
                <a href="Application_Onboarding_Guide_v1.4.docx" target="_blank" style="color:green;">Download Document Here</a>
 </div>
</body>
</html>



