<!DOCTYPE html>
<html>
<head>
<title>
  user detail
</title>
 <style>
.button {
  background-color: b5e7a0;
  border: none;
  color: white;
  padding: 15px 32px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
}
#bg1{
   background-color:silver;
}
   #d1{
     padding-top:100px;
     padding-left:200px;
}
</style>
</head>
<body id="bg1">
<div id="d1">
<h1 style="text-align:center; padding-right:300px;color:green;">User Details</h1>
<?php
  session_start();
  echo $_Session['username'];
  if($_SESSION['username']=='admin'){
echo "<table table style='border: solid 1px black;'>";
 echo "<tr><th>Id</th><th>Domain</th><th>username</th><th>Email</th><th>Project</th></tr>";

class TableRows extends RecursiveIteratorIterator { 
    function __construct($it) { 
        parent::__construct($it, self::LEAVES_ONLY); 
    }

    function current() {
        return "<td style='width: 150px; border: 1px solid black;'>" . parent::current(). "</td>";
    }

    function beginChildren() { 
        echo "<tr>"; 
    } 

    function endChildren() { 
        echo "</tr>" . "\n";
    } 
} 

$servername = "localhost";
$username = "root";
$password = "12345";
$dbname = "hr";
try {
    $conn = new PDO("mysql:host=$servername;dbname=hr", $username, $password);
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $stmt = $conn->prepare("SELECT id, domain, username, email, project FROM users"); 
    $stmt->execute();

    // set the resulting array to associative
    $result = $stmt->setFetchMode(PDO::FETCH_ASSOC); 

    foreach(new TableRows(new RecursiveArrayIterator($stmt->fetchAll())) as $k=>$v) { 
        echo $v;
    }
}
catch(PDOException $e) {
    echo "Error: " . $e->getMessage();
}
$conn = null;
echo "</table>";
}
else
 {
   echo "<h1>Sorry you are not admin</h1>";
 }
?>
 <div>
     <button type="submit" class="button"><a href="nav.php">Dasboard</a></button>
  </div>
 
</div>
</body>
</html>
