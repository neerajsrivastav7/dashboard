<?php
session_start();
        if (!isset($_SESSION['username'])) {
                $_SESSION['msg'] = "You must log in first";
                header("location: login.php");
        }
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>NLESANDBOX</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
 <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
  <link href="custom.css" rel="stylesheet"/>

    <style>
.error {color: #FF0000;}
</style>
        <script>
           $(document).ready(function(){
               $("#appOnBoard").click(function()
                   {
                        $("#appOnBoard").css("text-decoration", "underline");
                        $("#dataDiv").load("aobg.php #aobgd");
                 });
              });

           $(document).ready(function(){
             $("#oog").click(function()
                {
                    $("#oog").css("text-decoration", "underline");
                    $("#dataDiv").load("oog.php #oogd");
                });
            });
          $(document).ready(function(){
             $("#tog").click(function()
               {
                  $("#tog").css("text-decoration", "underline");
                  $("#dataDiv").load("tog.php #togd");
               });
           });
       $(document).ready(function(){
           $("#reg").click(function()
               {
                  $("#reg").css("text-decoration", "underline");
                  $("#dataDiv").load("reg.php #rid");
               });
        });
         $(document).ready(function(){
           $("#duser").click(function()
               {
                  $("#duser").css("text-decoration", "underline");
                  $("#dataDiv").load("del.php #did");
               });
        });

        </script>
  </head>

<body>
  <?php if(isset($_SESSION['username'])){ ?>
  <div class="container id10">
       <div class="row row1">
             <div class="col-md-4 row_col1">
                 <div class="col1data" style="float:left;">
                          <figure>
                           <?php
                                include('connection.php');
                                $var=$_SESSION['username'];
                                $sql ="SELECT domain from users WHERE username='$var'";
                                $stmt = $conn->query($sql);
                                $row =$stmt->fetchObject();
                                $dom=$row->domain;
                               
                            ?>
                            <img id="imid" style="align:center; float:left; height:40px;" src="images/<?php echo $dom ?>.png" alt="Cinque Terre">
                           <!-- <h3><figcaption>NEC</figcaption></h3>-->
                            </figure>
                   </div>
               </div>
             <div class="col-md-4 row_col2">
                 <div class="col2data"><h3 id="h11">Welcome To NLE Sandbox</h3></div>
             </div>
	              <div class="col-md-4 row_col3">
                         <div class="col3data" style="float:right;"> 
                          <figure>
                             <img style="float:right;" src="male.png" class="img-circle" alt="Cinque Terre" width="60" height="60">
                             <h3><figcaption><?php echo $_SESSION['username'] ?></figcaption></h3>
                          </figure>
                       </div>
                     </div>
		</div>
              <div class="row" style="padding-top:20px;">
             <div class="col-md-12">
              <nav class="navbar navbar-expand-md  navbar-dark bg-primary">
                   <a class="navbar-brand" href="newnav.php">Home</a>

                  <ul class="navbar-nav">
                     <li class="nav-item">
                     <a class="nav-link" href="#"><strog>Sandbox Portal</strong></a>
                     </li>
                     <li class="nav-item dropdown">
                        <?php if($_SESSION['username']=='admin'){ ?><a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                        User Management
                     </a><?php } ?>
                      <ul class="dropdown-menu">
                      <?php if($_SESSION['username']=='admin'){ ?><li class="dropdown-item w3-bar-item w3-button"><span id="duser" style="color:black; cursor:pointer; text-align:left;">View User</li>
                       </li><?php } ?>
                      <?php if($_SESSION['username']=='admin'){ ?><li class="dropdown-item w3-bar-item w3-button">Create User</li><?php } ?> 
                      </ul>
                   </li>

    <!-- Dropdown -->
                  <li class="nav-item dropdown">
                      <a class="nav-link dropdown-toggle" href="#" id="navbardrop" data-toggle="dropdown">
                        Documents
                     </a>
                    <ul class="dropdown-menu">
                      <li class="dropdown-item w3-bar-item w3-button" ><span id="appOnBoard" style="color:black; cursor:pointer; text-align:left;">Application Onboarding Guide</li></li>
                      <?php if($_SESSION['username']=='admin'){ ?><li class="dropdown-item w3-bar-item w3-button" ><span id="oog" style="color:black; cursor:pointer;">Openstack Onboarding Guide</li><?php } ?> 
                      <?php if($_SESSION['username']=='admin'){ ?><li class="dropdown-item w3-bar-item w3-button" ><span id="tog" style="color:black; cursor:pointer;">Tenant Onboarding Guide</li><?php } ?> 
                   </ul>
               </li>
            </ul>
                    <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
                    <ul class="navbar-nav" style="float:right;">
                    <li class="fa fa-sign-out" style="font-size:18px"><a href="logout.php" style="color:white;">Logout</a></li>
                       </ul>
                    </div>
        </nav>
   </div>
 </div>
      <div class="row row3" style="padding-top:25px;">
      <div  class="col-md-12">
               <div id="dataDiv">
                  <div style="text-align:center">
                      <?php
// define variables and set to empty values
                   $usernameErr = $emailErr = $passwordErr="";
                   $username = $email = $password_1 = $password_2 = $project = $domain="";
                   $f1 = $f2 = $f = $f4 = $f5 = $f6=0;
                    if ($_SERVER["REQUEST_METHOD"] == "POST") {
                    $domain=$_POST["domain"];
                    $email=$_POST["email"];
                    $username=$_POST["username"];
                    $project=$_POST["project"];
                    $password_1=$_POST["password_1"];
                    $password_2=$_POST["password_2"];
                    if ($password_1!=$password_2) {
                        $passwordErr = "password is missmatch";
                   }
                   else
                    {
                       $f1=1;
                    }
                  $sql ="SELECT username from users WHERE username='$username'";
                  $stmt = $conn->query($sql);
                  $row =$stmt->fetchObject();
                  $user=$row->username;
                  if($username==$user)
                    {
                       $usernameErr = "User is alredy exits";
                    }
                  else
                    {
                       $f2=1;
                    }
                  $sql ="SELECT email from users WHERE username='$email'";
                  $stmt = $conn->query($sql);
                  $row =$stmt->fetchObject();
                  $email_1=$row->email;
                  if($username==$email_1)
                    {
                       $emailErr = "Email is alredy exits";
                    }
                  else
                    {
                       $f3=1;
                    }
                 if($f1==1 && $f2==1 && $f3==1)
                   {
                        $sql = "INSERT INTO users (domain,username, email, password,project)
                        VALUES ('".$_POST["domain"]."','".$_POST["username"]."','".$_POST["email"]."','".$_POST["password_1"]."','".$_POST["project"]."')";
                        if ($conn->query($sql))
                           {
			    header('location: newnav.php');
                          }
                   }
                }

function test_input($data) {
  $data = trim($data);
  $data = stripslashes($data);
  $data = htmlspecialchars($data);
  return $data;
}
?>
<form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>"> 
  <table align="center" class="table table-hover table-borderless">
  <tr>
    <td><h2>Register Here</h2></td>
    <td></td>
  </tr>
  </tr>
  <tr>
   <td><input type="text" name="domain" placeholder="Domain" required/><td>
   <td></td>
   </tr>
   <tr>
   <td><input type="text" name="username" placeholder="UserName" required/></td>
   <td><span class="error"> <?php echo $usernameErr;?></span></td>
   </tr>
   <tr>
   <td><input type="email" name="email" placeholder="Email" required/></td>
   <td><span class="error"><?php echo $emailErr;?></span></td>
   </tr>
   <tr>
   <td><input type="password" name="password_1" placeholder="Password" required/></td>
   <td><span class="error"> <?php echo $passwordErr;?></span></td>
    </tr>
   <tr>
   <td><input type="password" name="password_2" placeholder="Confirm Password" required/></td>
   <td><span class="error"><?php echo $nameErr;?></span></td>
   </tr>
   <tr>
   <td><input type="text" name="project" placeholder="Project" required/></td>
   <td><span class="error"><?php echo $nameErr;?></span></td>
  <tr>
  <tr>
  <td><input type="submit" name="submit" value="Submit"></td>
  <td></td>
    </tr>
  </table>
</form>
  </div>
                  </div>  
               </div>
            </div>
           <!-- <div class="col-md-3">
               <div class="customDiv3">LINKbar3</div>
            </div>-->
      </div>
</div>
</div>
<?php }
else header('location: login.php'); ?>
<body>
</html>


