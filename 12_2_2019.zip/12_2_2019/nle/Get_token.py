from keystoneauth1.identity import v3
from keystoneauth1 import session
from keystoneclient.v3 import client
import sys
UserName=sys.argv[1]
UserPassword=sys.argv[2]
UserDomain=sys.argv[3]
auth = v3.Password(auth_url='http://192.168.30.5:5000/v3',
                   username=UserName,
                   password=UserPassword,
#                   project_id='RI_EMISSION',
#                   user_domain_id='4ec8cbb5c8fe45c4a25456e09e818415'
                   user_domain_name=UserDomain)
#auth = v3.Password(auth_url='http://192.168.30.5:35357/v3',
#                   username='admin',
#                   password='KDYc430Vp4Nsi1jiMbMypeCDviJTM016UynN6egp',
#                   project_id='13de5928f71148a6a1f398d81e92f38d',
#                   user_domain_id='default')
sess = session.Session(auth=auth)
try:
	var=sess.get_token();
        print "true"
except:
	print "false"
#ks = client.Client(session=sess)
#users = ks.users.list()
#print sess.get_token()
#print type(sess.get_token())

