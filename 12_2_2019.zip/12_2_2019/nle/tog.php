<?php
        session_start();
//        echo $_SESSION['username'];
        if (!isset($_SESSION['username'])) {
                $_SESSION['msg'] = "You must log in first";
                header("location: login.php");
        }

/*      if (isset($_GET['logout'])) {
                session_destroy();
                unset($_SESSION['username']);
                header("location: login.php");
        }*/

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>NLE SANDBOX</title>
     <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>
<body>
              <div id="togd" class="shadow-lg p-3 mb-5 bg-white rounded">
               <h3 style="padding-left:0px;color:green; text-align:center;">Description of Tenant Onboarding Guide</h3></br>
                <p align="justify" style="font-size:14px;">
                   This guide demonstrates the process of onboarding a tenant in Foundation cloud. Sandbox environment uses Openstack as the cloud foundation. The document covers both CLI and Web UI methods of on-boarding a tenant.
In summary, this document explains how to create a project and add an administrator of that project. In networking context, it covers steps to create public and private networks, security groups, floating IP assignment. Covered topics include OS image download and upload process, flavor and key management, user segregation at Domain and project level. It also describes multi-tenancy architecture and capacity overview of the existing cloud setup.
                 </p>
                 <a href="Tenant_Onboarding_Guide_v1.5.docx" target="_blank" style="color:green;">Download Document Here</a>


 </div>
</body>
</html>

