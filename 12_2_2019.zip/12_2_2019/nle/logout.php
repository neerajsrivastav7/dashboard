<?php
  session_start();
  session_unset($_session['username']);
  header("location: login.php");
?>
