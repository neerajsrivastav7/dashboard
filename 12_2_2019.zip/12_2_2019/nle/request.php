<script>
   var res = "success";
</script>
<?php
   $var= "<script>document.writeln(res);</script>";
   echo $var;
?>
