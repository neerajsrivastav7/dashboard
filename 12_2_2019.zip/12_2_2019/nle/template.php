       <div class="row row1">
             <div class="col-md-4 row_col1">
                 <div class="col1data" style="float:left;">
                          <figure>
                           <?php
                                $var=$_SESSION['domain'];
                                $dom=$var
                            ?>
                            <img id="imid" style="align:center; float:left; height:40px;" src="images/<?php echo $dom ?>.png" alt="Cinque Terre">
                           <!-- <h3><figcaption>NEC</figcaption></h3>-->
                            </figure>
                   </div>
               </div>
             <div class="col-md-4 row_col2">
                 <div class="col2data"><h3 id="h11">Welcome To NLE Sandbox</h3></div>
             </div>
                      <div class="col-md-4 row_col3">
                         <div class="col3data" style="float:right;">
                          <figure>
                             <img style="float:right;" src="male.png" class="img-circle" alt="Cinque Terre" width="60" height="60">
                             <h3><figcaption><?php echo $_SESSION['username'] ?></figcaption></h3>
                          </figure>
                       </div>
                     </div>
                </div>
              <div class="row" style="padding-top:20px;">
             <div class="col-md-12">
              <nav class="navbar navbar-expand-md  navbar-dark bg-primary">

                  <ul class="navbar-nav">
                      <li class="nav-item">
                      <a class="nav-link hower" href="newnav.php" style="color:white;">Home</a>
                     </li>
                     <li class="nav-item">
                     <a class="nav-link hower" href="http://192.168.30.5/auth/login/?next=/" style="color:white;"><strog>Sandbox Portal</strong></a>
                     </li>
                     <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle hower" href="#" id="navbardrop" data-toggle="dropdown" style="color:white;">
                        User Management
                     </a>
                      <ul class="dropdown-menu">
                     <!-- <li class="dropdown-item w3-bar-item w3-button"><a href="piechart1.php">Resource Overview</li>-->
                      <li class="dropdown-submenu">
                          <a  class="dropdown-item" tabindex="-1" href="#">Resource overview</a>
                          <ul class="dropdown-menu">
                                <?php
                                  $var=$_SESSION['username'];
                                  $username1 =$var;
                                  $return_string=exec("python KeyStoen.py  $username1");
                                  $project_arr = explode('.', $return_string);
                                  $lenth = sizeof($project_arr);
                                  for ($x = 0; $x<$lenth-1; $x++) {
                                ?>
                                <li class="dropdown-item w3-bar-item w3-button"><a href="piechart1.php?id=<?php echo $project_arr[$x]; ?>" id="<?php echo $project_arr[$x]; ?>"><?php echo $project_arr[$x]; ?></a></li>
                                <?php } ?>
                            </ul>
                      </li>
                      <?php if($_SESSION['username']=='admin'){ ?><li class="dropdown-item w3-bar-item w3-button"><a href="Del2.php">View User</li><?php } ?>
                      
                      <li class="dropdown-item w3-bar-item w3-button"><a href="changepassword.php">Reset Password</li>
                      </ul>
                   </li>

    <!-- Dropdown -->
                  <li class="nav-item dropdown">
                      <a class="nav-link dropdown-toggle hower" href="#" id="navbardrop" data-toggle="dropdown" style="color:white;">
                        Documents
                     </a>
                    <ul class="dropdown-menu">
                      <li class="dropdown-item w3-bar-item w3-button" ><span id="appOnBoard" style="color:black; cursor:pointer; text-align:left;">Application Onboarding Guide</li>
                      <?php if($_SESSION['username']=='admin'){ ?><li class="dropdown-item w3-bar-item w3-button" ><span id="oog" style="color:black; cursor:pointer;">Openstack Onboarding Guide</li><?php } ?>
                      <?php if($_SESSION['username']=='admin'){ ?><li class="dropdown-item w3-bar-item w3-button" ><span id="tog" style="color:black; cursor:pointer;">Tenant Onboarding Guide</li><?php } ?>
                    <li class="dropdown-item w3-bar-item w3-button" ><span id="gos" style="color:black; cursor:pointer;">Glossary</li>
                   </ul>
               </li>
            </ul>
                    <div class="collapse navbar-collapse justify-content-end" id="navbarSupportedContent">
                    <ul class="navbar-nav" style="float:right;">
                    <li class="fa fa-sign-out" style="font-size:18px"><a href="logout.php" style="color:white;">Logout</a></li>
                       </ul>
                    </div>
        </nav>
   </div>
 </div>

