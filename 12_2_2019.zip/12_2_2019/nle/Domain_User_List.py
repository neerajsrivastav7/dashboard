from keystoneauth1.identity import v3
from keystoneauth1 import session
from keystoneclient.v3 import client
import sys
auth = v3.Password(auth_url='http://192.168.30.5:5000/v3',
                   username='admin',
                   password='KDYc430Vp4Nsi1jiMbMypeCDviJTM016UynN6egp',
                   user_domain_id='default')
sess = session.Session(auth=auth)
ks = client.Client(session=sess)
domain_name=sys.argv[1]
domain_list=ks.domains.list()
domain_list_len=len(domain_list)
for i in range(domain_list_len):
	if domain_list[i].name==domain_name:
		break
domain_id=domain_list[i].id
user_list=ks.users.list(project=None, domain=domain_id, group=None, default_project=None)
user_list_len=len(user_list)
user_list_arr=[]
str1=""
for i in range(user_list_len):
	str1=str1+user_list[i].name
        str1=str1+"."
print str1

