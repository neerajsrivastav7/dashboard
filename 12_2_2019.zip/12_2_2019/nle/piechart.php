<?php
session_start();
        if (!isset($_SESSION['username'])) {
                $_SESSION['msg'] = "You must log in first";
                header("location: login.php");
        }
?>
<?php
$given_project_id= '13de5928f71148a6a1f398d81e92f38d';
$w=exec("python nova_limits.py $given_project_id");
$w1 = trim($w,"}");
$myArray = explode(',', $w1);
$newarray=  $myArray[1];
$array1 = explode(':', $newarray);
$a1 = array();
$lenth = sizeof($myArray);
for( $x = 0; $x < $lenth; $x++) {
            $v1 = $myArray[$x];
            $array1 = explode(':', $v1);
            $array2 = explode("'", $array1[0]);
            $a1[$array2[1]] = $array1[1];
         }
$c11=$a1['maxTotalInstances']-$a1['totalInstancesUsed'];
$c12=$a1['totalInstancesUsed'];
$c11=(int)$c11;
$c12=(int)$c12;
$dataPoint1 = array(
        array("label"=>"Used Intances", "y"=> $c12),
        array("label"=>"vacend Instances", "y"=> $c11)
)
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>NLE Sandbox</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
 <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
  <script src="canvasjs.min.js"></script>
  <link href="custom.css" rel="stylesheet"/>
  <style>
    .hower:hover {
  background-color: #555;
  color: white;
}
  </style>
        <script>
        window.onload = function() {
        var chart = new CanvasJS.Chart("chart1", {
        animationEnabled: true,
        data: [{
                type: "pie",  
             	indexLabel: "{y}",
		yValueFormatString: "#",
		indexLabelPlacement: "inside",
		indexLabelFontColor: "#36454F",
		indexLabelFontSize: 18,
		indexLabelFontWeight: "bolder",
		showInLegend: true,
		legendText: "{label}",
		dataPoints: <?php echo json_encode($dataPoint1, JSON_NUMERIC_CHECK); ?>
        }]
   });
  chart.render();  
}
           $(document).ready(function(){
               $("#appOnBoard").click(function()
                   {
                        $("#appOnBoard").css("text-decoration", "underline");
                        $("#dataDiv").load("aobg.php #aobgd");
                 });
              });

           $(document).ready(function(){
             $("#oog").click(function()
                {
                    $("#oog").css("text-decoration", "underline");
                    $("#dataDiv").load("oog.php #oogd");
                });
            });
          $(document).ready(function(){
             $("#tog").click(function()
               {
                  $("#tog").css("text-decoration", "underline");
                  $("#dataDiv").load("tog.php #togd");
               });
           });
       $(document).ready(function(){
           $("#reg").click(function()
               {
                  $("#reg").css("text-decoration", "underline");
                  $("#dataDiv").load("reg.php #rid");
               });
        });
        $(document).ready(function(){
           $("#duser").click(function()
               {
                  $("#duser").css("text-decoration", "underline");
                  $("#dataDiv").load("del.php #did");
               });
        });
        </script>
  </head>

<body>
  <?php if(isset($_SESSION['username'])){ ?>
  <div class="container id10">
      <?php include('template.php'); ?>
      <div class="row row3" style="padding-top:25px;">
     <div  class="col-md-12">
               <div id="dataDiv" class="customDiv2">
                   <div class="row">
                       <div class="col-md-4">
                           <h4 style="margin-left:26%;">instances</h4>
                           <h5></h5>
                           <div id="chart1" style="height: 250px; width:250px;"></div>
                       </div>
                       <div class="col-md-4"> 
                       </div>
                       <div class="col-md-4">
                       </div>
                   </div>
               </div>
            </div>
           <!-- <div class="col-md-3">
               <div class="customDiv3">LINKbar3</div>
            </div>-->
      </div>
</div>
</div>
<?php }
else header('location: login.php'); ?>
<body>
</html>

