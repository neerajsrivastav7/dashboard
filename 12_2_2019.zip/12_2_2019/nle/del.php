<!DOCTYPE html>
<html lang="en">
<head>
  <title>NLE Sandbox</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
 <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
 </head>
   <body>
        <div id="did" class="shadow-lg p-3 mb-5 bg-white rounded">
           <h1 style="text-align:center;">User Details</h1>
           <form action="delete.php" method="post">
	 <table class="table table-borderless">
      <thead>
        <tr>
                <th> &nbsp; </th>
                <th> Domain </th>
                <th> Username </th>
                <th> Email Id</th>
                        <th> Project </th>
        </tr>
    </thead>
    <tbody>
        <?php
                include('connection.php');
                $result = $conn->prepare("SELECT * FROM users ORDER BY username");
                $result->execute();
                for($i=0; $row = $result->fetch(); $i++){
        ?>
        <tr class="record">
                <td><input name="selector[]" type="checkbox" value="<?php echo $row['username']; ?>"></td>
                <td><?php echo $row['domain']; ?></td>
                <td><?php echo $row['username']; ?></td>
                <td><?php echo $row['email']; ?></td>
                        <td><?php echo $row['project']; ?></td>
        </tr>
        <?php
                }
        ?>
    </tbody>
    <tr>
            <td><button type="submit" class="btn btn-danger">Delete</button></td>
   </tr>
    </table>
     </form>
   </div>
  </body>
</html>
