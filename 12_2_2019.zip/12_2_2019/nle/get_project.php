<?php
$var="admin";
$username1 =$var;
$return_string=exec("python KeyStoen.py  $username1");
$project_arr = explode('.', $return_string);
$lenth = sizeof($project_arr);
for( $i = 0; $i < $lenth; $i++)
   {
      echo $project_arr[$i];
   }
?>
