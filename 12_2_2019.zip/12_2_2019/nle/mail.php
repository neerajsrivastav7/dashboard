<?php
echo "neeraj";
$to = "neeraj.srivastava@india.nec.com";
$subject = "My subject";
$txt = "Hello world!";
$headers = "From: webmaster@example.com" . "\r\n" .
"CC: somebodyelse@example.com";

if(mail($to,$subject,$txt,$headers))
{
  echo "hello";
}
?>
