from keystoneauth1.identity import v3
from keystoneauth1 import session
from keystoneclient.v3 import client
import sys
from novaclient import client

auth = v3.Password(auth_url='http://192.168.30.5:5000/v3',
                   username='admin',
                   password='KDYc430Vp4Nsi1jiMbMypeCDviJTM016UynN6egp',
                   project_id='13de5928f71148a6a1f398d81e92f38d',
                   user_domain_id='default')
sess = session.Session(auth=auth)
nova = client.Client('2.1', session=sess)


given_tenant = sys.argv[1]

nova = client.Client('2.1', session=sess)
compute_limits= nova.limits.get(tenant_id=given_tenant).absolute
l1 = list(compute_limits)
limits = dict(map(lambda x: (x.name, x.value), l1))
print limits
